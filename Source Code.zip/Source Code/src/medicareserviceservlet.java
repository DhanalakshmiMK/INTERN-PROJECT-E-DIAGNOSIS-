
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/medicareserviceservlet")

public class medicareserviceservlet extends HttpServlet 
{
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {
        try
        {
               					HttpSession hs1=request.getSession();
               					HttpSession hs2=request.getSession();
               		         hs2.setAttribute("user_id",request.getParameter("tf1"));

                                String user=(String)hs1.getAttribute("tf1");
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");     
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                String mid=request.getParameter("tf1");
                                int id=Integer.parseInt(mid);
                                String ms=request.getParameter("tf2");
                                String sd=request.getParameter("tf3"); 
                                String amt=request.getParameter("tf4");
                                int am=Integer.parseInt(amt);
                                RequestDispatcher rd=null;
                                PreparedStatement stmt=con.prepareStatement("insert into medicare_services values(?,?,?,?)");
                                stmt.setInt(1,id);
                                stmt.setString(2,ms);
                                stmt.setString(3,sd);
                                stmt.setInt(4,am);           
                                PreparedStatement stmt1=con.prepareStatement("update doctor set medicare_service_id=? where doctor_id=?");
                                stmt1.setInt(1,id);
                                stmt1.setString(2, user);               
                                stmt1.executeUpdate();
                                stmt.executeUpdate();
                                
           //out.println("<body bgcolor=lightpink><b><center><h1>Your details are submitted successfully.</h1><center></b></body>");
      response.sendRedirect("nextpagedoctor.jsp");
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
  }
