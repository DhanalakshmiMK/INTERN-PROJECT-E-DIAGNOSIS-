import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/RegisterdoctorServlet")
public class RegisterdoctorServlet extends HttpServlet  
{
                
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {

        try
        {
               HttpSession hs1=request.getSession();
                                hs1.setAttribute("user_id",request.getParameter("tf1"));
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");

                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                String doctorid=request.getParameter("tf1");
                                String firstname=request.getParameter("tf2");
                                String lastname=request.getParameter("tf3");
                                String age=request.getParameter("tf4");
                                int n=Integer.parseInt(age);
                                String gender=request.getParameter("tf");
                                String dob=request.getParameter("tf5");
                                String cno=request.getParameter("tf6");
                                long no=Long.parseLong(cno);
                                String alcno=request.getParameter("tf7");           
                                long no1=Long.parseLong(alcno);
                                String emailid=request.getParameter("tf8");
                                String pwd=request.getParameter("tf9");
                                String add1=request.getParameter("tf10");
                                String add2=request.getParameter("tf11");
                                String city=request.getParameter("tf12");
                                String state=request.getParameter("tf13");
                                String zip=request.getParameter("tf14");
                                String degree=request.getParameter("tf15");
                                String speciality=request.getParameter("tf16");
                                String workhours=request.getParameter("tf17");
                                String clinicname=request.getParameter("tf18");
                                String medicareserviceid=request.getParameter("tf19");
                                int n1=Integer.parseInt(medicareserviceid);
                                PreparedStatement stmt=con.prepareStatement("insert into doctor values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                                stmt.setString(1,doctorid);
                                stmt.setString(2,firstname); 
                                stmt.setString(3,lastname);
                                stmt.setInt(4,n); 
                                stmt.setString(5, gender);
                                stmt.setString(6, dob);
                                stmt.setLong(7, no);
                                stmt.setLong(8, no1);
                                stmt.setString(9, emailid);
                                stmt.setString(10, pwd);
                                stmt.setString(11, add1);
                                stmt.setString(12, add2);
                                stmt.setString(13, city);
                                stmt.setString(14, state);
                                stmt.setString(15, zip);
                                stmt.setString(16, degree);
                                stmt.setString(17, speciality);
                                stmt.setString(18, workhours);
                                stmt.setString(19, clinicname);   
                                stmt.setString(20, medicareserviceid);
                               
                                stmt.executeUpdate();
                                PreparedStatement stmt1=con.prepareStatement("insert into status values(?,?,?)");
                                stmt1.setString(1,doctorid);
                                stmt1.setString(2,"doctor");
                                stmt1.setString(3,"Not-approved");
                                stmt1.executeUpdate();

                                response.sendRedirect(" http://localhost:8080/E-DIAGNOSIS/nextpagedoctor.jsp");
            
       }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
  }
