
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import test.Medical_Test_History;

@WebServlet ("/select")
public class select extends HttpServlet 
{
                
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
                {
                   //System.out.println("In the servlet");
                                try
                                {
                                HttpSession hs1=request.getSession();
                                String customer_id = request.getParameter("tf1");
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                PreparedStatement stmt=con.prepareStatement("select report_id,doctor_id,medicare_service_id, diag1_actual_value,diag1_normal_range,customer_id from medical_test_history where customer_id=?");
                                stmt.setString(1, customer_id);
                                ResultSet rs=stmt.executeQuery();
                                //request.setAttribute("result",rs);
                                 
                                Medical_Test_History medicalTestHistory = new Medical_Test_History();
                                while (rs.next())
                               { 
                                     medicalTestHistory.setReport_id(rs.getInt(1));
                                     medicalTestHistory.setDoctor_id(rs.getString(2));
                                     medicalTestHistory.setMedicare_service_id(rs.getInt(3));
                                     medicalTestHistory.setActual_value(rs.getInt(4));
                                     medicalTestHistory.setNormal_range(rs.getInt(5));
                                     medicalTestHistory.setCustomer_id(rs.getString(6));
                                }
                                request.setAttribute("Medical_Test_History", medicalTestHistory);
                                request.setAttribute("Medical_service_table", 0);
                                
                                RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/req.jsp");
                                reqDis.forward(request,response);
                                 
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                }
}

