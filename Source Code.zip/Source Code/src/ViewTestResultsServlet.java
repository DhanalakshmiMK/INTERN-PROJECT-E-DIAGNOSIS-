
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewTestResultsServlet")
public class ViewTestResultsServlet extends HttpServlet 
{
                
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
                {
                                try
                                {
                                                HttpSession hs1=request.getSession();
                                                String user=(String)hs1.getAttribute("user_id");
                                                
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                PreparedStatement stmt=con.prepareStatement("select * from medical_test_history where customer_id=?");
                                stmt.setString(1,request.getParameter("id"));
                                System.out.println(request.getParameter("id"));
                                ResultSet rs=stmt.executeQuery();
                                request.setAttribute("result",rs);
                                RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/ViewTestResults.jsp");
                                reqDis.forward(request,response);
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                }
}

