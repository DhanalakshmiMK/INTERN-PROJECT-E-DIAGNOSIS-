
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/Raisecheckupservlet")


public class Raisecheckupservlet extends HttpServlet 
{
                
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {

        try
        {
                                HttpSession hs1=request.getSession();
                                hs1.setAttribute("user_id",request.getParameter("id"));
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                String cusid=request.getParameter("id");
                                String name=request.getParameter("name");
                                String date=request.getParameter("date");
                                String medicare=request.getParameter("medicare");
                                String docid=request.getParameter("docid");
                                RequestDispatcher rd=null;
                                PreparedStatement stmt=con.prepareStatement("insert into raisecheckup values(?,?,?,?,?,?)");
                                stmt.setString(1,cusid);
                                stmt.setString(2,name);
                                stmt.setString(3,date);
                                stmt.setString(4,medicare); 
                                stmt.setString(5, docid);
                                stmt.setString(6,"NO");
                                stmt.executeUpdate();
                                response.sendRedirect("nextpagecustomer.jsp");
       }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
  }
