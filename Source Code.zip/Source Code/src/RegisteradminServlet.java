import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet ("/RegisteradminServlet")
public class RegisteradminServlet extends HttpServlet 
{
                
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
     {

        try
        {
                                HttpSession hs1=request.getSession();
                                hs1.setAttribute("user_id",request.getParameter("tf1"));
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                String cusid=request.getParameter("tf1");
                                String firstname=request.getParameter("tf2");
                                String lastname=request.getParameter("tf3");
                                int age=Integer.parseInt(request.getParameter("tf4"));
                                String gender=request.getParameter("tf5");
                                String dob=request.getParameter("tf6");
                                String no=request.getParameter("tf7");
                                String no1=request.getParameter("tf8");
                                String emailid=request.getParameter("tf9");
                                String pwd=request.getParameter("tf10");
                                RequestDispatcher rd=null;
                                PreparedStatement stmt=con.prepareStatement("insert into admin values(?,?,?,?,?,?,?,?,?,?)");
                                stmt.setString(1,cusid);
                                stmt.setString(2,firstname);
                                stmt.setString(3,lastname);
                                stmt.setInt(4,age); 
                                stmt.setString(5, gender);
                                stmt.setString(6, dob);
                                stmt.setString(7, no);
                                stmt.setString(8, no1);
                                stmt.setString(9, emailid);
                                stmt.setString(10, pwd);
                                stmt.executeUpdate();
                                // close con();
                                response.sendRedirect("http://localhost:8080/E-DIAGNOSIS/nextpageadmin.jsp");
           }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
  }
