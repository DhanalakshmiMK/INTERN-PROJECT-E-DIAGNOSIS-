
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MedicareServiceTableServlet")

public class MedicareServiceTableServlet extends HttpServlet 
{
                
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
                {
                                try
                                {
                                HttpSession hs1=request.getSession();
                                String user=(String)hs1.getAttribute("user_id");
                                //String doctor_id=(String)hs1.getAttribute("cus_id");
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                
                                
                                PreparedStatement stmt=con.prepareStatement("select medicare_service from medicare_services ");
                                ResultSet rs=stmt.executeQuery();

                                ArrayList <String> Medicare_services_list = new ArrayList <String>();
                                while (rs.next())
                                {
                                                Medicare_services_list.add(rs.getString(1));
                                }
                                
                                request.setAttribute("Medicare_services_list", Medicare_services_list);
                                
                                
                                PreparedStatement stmt1=con.prepareStatement("select * from medicare_services where medicare_service=?");
                                stmt1.setString(1,request.getParameter("tf4"));
                                
                                System.out.println("Query" + stmt1.toString());
                                ResultSet rs1=stmt1.executeQuery();
                                request.setAttribute("Medical_service_table",1);
                                request.setAttribute("result",rs1);
                
                                
                                //RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/DisplayMedicareServices.jsp");
                                RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/ViewMedicareService.jsp");
                                reqDis.forward(request,response);
                                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                }
}
